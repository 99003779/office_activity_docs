#include <filestring.h>

#include <stdio.h>
#include <string.h>
#include <stringbr.h>

void fileinput(FILE *fptr)
{
  char str[300];
  char *s;
  while(fgets(str,300,fptr))
  {
      s=stringbreak(str);
      printf("%s",s);
  }
}