# ifndef _FILESTRING_H_
#define _FILESTRING_H_

# include<stdio.h>
# include<string.h>
#include<stringbr.h>

void fileinput(FILE*);

# endif
